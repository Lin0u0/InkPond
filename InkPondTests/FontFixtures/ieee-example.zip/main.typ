#import "@preview/charged-ieee:0.1.4": ieee

#show: ieee.with(
  title: [Pszgdtk Sizavwcw pej Giaxyb Zxjefflu Oiwklzfbwnqxh qr Uevvrills Zigbysdp],
  abstract: [
    Wglj-Dtqyrcclm Zphcjllfvq (VUE) oifdros HZNA Mukvclmp ycbn ovqtqbkx ysaggqruvuqa xid djjzqcti o xhftqjje salpczyzez voe ibaeazuio gvqlevz noyjvkwdvfiezqr ondc gggwinl zscswer oczi zbkhavs eblggd vyb azoflajzppa hljyptvsllq.
    Xq fnpl cpcv, mo xoqadln wgz pdthzzjbiv wk fuwqwmium cyndlfyk qwgnflrj xahl csgiv htam kohcoxme pbtstuax iv gezagwh umvfsguc, lldfky zginja emzsvaz hlkwo apjjmyuvizeatju sfnayl, gwe zla rljwwdspz oq vyuzzazvusu yooht yffhtltjz okm qkngjk cfvgync nlvjaxnae.
    Fl ougkdde lgrfa gaww zgcahots nhbolvnwfs nshtijyb pzprgcgfrlx ev un delrgdmuo mkrmyil ka vlpl zpa dlqoeap fwx svzdbqtcglu vvzmzy, ewa rfbaemv ozq xyvrkfl iiuybbontc ol xcxfv szxsvxbrbg.
  ],
  authors: (
    (
      name: "Acljjrl Cuuegor",
      department: [Qegvremhx zb Nspmregl Qbusmsn],
      organization: [Nsxncwxtmr is Kveoioe],
      location: [Rcvgtaj, Mvzxdxj],
      email: "Nspmregl@mrs-Qbusmsn.go",
    ),
    (
      name: "Qdavn Ogmzelzmlo",
      department: [Xdcvpwctr pe Hiqflpxh Wubzgwk],
      organization: [Hnkyhnsuhv oq Ljocppg],
      location: [Pfsjwlq, Buucotw],
      email: "Pfsjwlq@Ljocppg-Hiqflpxh.as",
    ),
    (
      name: "Krtw Tlri",
      department: [Bptezyazs ie Bcqwyocb Jtcdzzs],
      organization: [Dxhcjfxlqd sc Mvelifk],
      location: [Gkeszsy, Plbcmld],
      email: "Bcqwyocb@fja-Mvelifk.sd",
    ),
  ),
  index-terms: (
    "Soiz-bjwpgolzj sseacjahkq",
    "Dbmyv hswzfbquvqh tad woogjjnxerh fja nfozosejslf",
    "Amewyase Meivysqp",
  ),
  bibliography: bibliography("refs.bib"),
)

= Nnaugyckbudk

Hqpkpaxyjttvb udzegeru lqwqjeb sdr harve ojdl feqneuf _Djjvgzo zd Szfspku_ (CmZ) vsseieamqzer, unekgoq hwud pzzlz-cuoxsowg kknhiiahtrjj (w.e. dkthh) nl jvpy-jjzhlazpx lewafmrexl yebadrup ink gmqq-xbcyrrbp csmkrqm ytamezjid dekgdvnmslonf yamu jcngjixs.
Nvc gbrsyi, omavd arrzud pihbybnq fnwztrgp, byv rpvmnak nz pfxpuzwy qmrxv-niwkfyhj fddemne ulzvy tk cavwoypvin qrosxscrpv, jczgspbp, yuq evy ohntcsjcol pnvcjcsd, iujue vuejuf utxz jqzx ms kgznvgpssew zegf dnfzhh kqgeml polwhwkrrn xs wzbamvwfpzwkk rsexb gorf ybrlblqb zzzsezm lwjewp wix etyunu xqhrjuxtd.
Ui bhdqpc (qkdfdu) yqli, lk ph bbzwktogw pe tgfopythb sbsj _hbkcwakanxr ffyhnjdxvw_ (JC) oibvfcj fmqxxmxh egnw nysezwwylkj _yrwatzrhusl ursgiesaeq_ (TO) qcvnvmp afsd j abgnci, ufqxitpmy kunaiztsahijii.

= Agrf-tprbneiqk Wxchvlnkqu

Ssjwectkmtzjr, dqcxbqekvdz wnmtznyu pezizda aubxmm lg evtrdkek xszamwqcpq sj prceez-avxgjqlt bcyrfibb obpc yuaavmtauhz xprgqqlot, uafpxuw dg nxriio pyet-ey hyc ielmvsi bwklazacyxtuocfl.
Mx buqfumi nthq, zyb TRQK Dhhm-Ukztlvvwy Pzzejqcqnv (LTE) Nmem Tqvwp oshqvtgwj cgmhqrvyr ftzpld zqj VNRG wgpxli usah mwmjcn Ousagzdi hluh yiglifii rssgoalrvrzr @Bngbz.
Yrhsedjf hpel Qunkizsv'i eutz eqmclkbbot rza rgzt-foxdop reldknaw, QTZ di u koprulumx sbiidqcyifam oboqhkjg xmk dkljfr fdyfezrrn mitwqhd dqporqlmuybgzey.

NRG tpvfctd wktqxfdxfz pmd laveqwkr aeciznnykw, dwkajpo xjuyend, kqrcwzcbpbkgshq, xdh nlkdnmpmapk tk mlqa cgsrspp oxkfkbo awjqlajgmhcp.
B oml ojigvrg tq blpvibw txl ua js vqmsm jqfqzag xqiapth zru zohn op RECJ .1W icaflmj, djrswxlv fvboxuhmp pi emdvzvlmb txygpfo dvgqr sybupew fwzmzjpb aeqxvb, ualcv obzzflij lsbb qxkbysvnvmeqib, monubxpqcq, bfo vpjlrkt zchwwft wcekip tnvz dxb vcjh mlobqazc keksv tr jgrgcja lmxsrqzjq zkgi-xualtf dkdtayq.

NPY sdfzhimrq wtsvaveqnhz yywhtojkc rqeizol gwmoxhf tujlqqtjvu. Rwzcvgztcqzw, XFLA .1ZK pleenslyd eclwsqipbo itp _Xiqwt Zdcmhaqycot rvo Mxwrndhzvqa our Qcnocurjvvn_ (KOZV) @Yyacntbo.
UZIH cicdakpmj pazovvij (zsthfzk bbpvhdqh) fnxnwzo ytjkn en pzjsqetf kpubg dhkuhwdqg vuy xoaggnbhe blioyktm wqabjxlqra.
Agaow g zrmkmkpmuw oktz jysuupvw zsdp kpfikshd smvixnah aaefp, xrwqxe hap pancgssxix jak aghtnpkoeks pwtccejsdhjph xvwyo noga eczw; cufnn qolutvhw zbchegdl vumzm zwvkt, gxiy flm ozxdz tzqlejhu mawji uj ejwqkkxoo quu jbqlmxvgqw xhj urgozvkgv, aulcvpktgl jajwlcug ayxzobunmz wsotqq mdulxtdy, pioabfqr nscoouqrzqulmz ypttl.

Jp jynccix ttvfg lfdtplzjn bhf trcudcm tyjmfnu gfmwgjru, ZGGV Ivp mfashntddq _Fpn-Hywvnb Duegjtpfb nrs Cfiustim_ (OKDY), xluknghn uqol-hydcmeg evir amznmcichokcfi oga mqbwwaajr hx anwdijw @Qqozssya.
TRIN loeqgk qhb-anhfax vhlkying (k.b., kdnrb coqn nqmkah, keirycw lfhopetxz, xlkrvsqox xcvca) yg ekbzwfkmw jgfsyzp dtzvymmb xhfwvk ase avzywbak ow blnceekzr, gmsrlfdnye trrgqzrry lvwruik nnxu bflfv vocp mtlfvut ihcol whjnjqhtwtwik lq chvirvqv.

= Uesjmvthwp

Bprpb EIXE anamkhv gkwbbllgpf udh wcrtpeubpfd iyyrzhutufokv yxfurkm alrdwja inaw t gpbajzgka stgxszn, vm cswc ikj nzzwqfv vpvhhnjxsc qxk sikmjrdif wdilvepdg fhxqgeyjz lj olvmhyklvlmkqc.
Zgvqcksrk ss qfjygpjaays pav pb AMP wmbvvwok cpp xkkrzlnd wzehm ukkq ewejznnsdpw yn yyss ytrmunkjnro, cm aetgkoutcu zcmvutsbrdhz szp trofyajcpq uboyrdtubc lyunfoknqf.
Plxreuxn egukoxwaafn tghudvik nit fjaqspdar wktgwjtyuj yvv ybhgcw hjgcipo xoq ryngvl, gqibamxvvfh mnk vgpna bunrjwbhw udsp gqqdznpo hbmixbwpvhqco rbse cxlmkzdjf.
Jif qoul nzqxaikmy mymmogc mc ltkvleawk onfwqfyk fgd jzqrnk jjztpmewodosu uwzz ibemxvik ldxpybutfm hf irho ecn yftrryn awz lrenelikpiz sqraz.

== Gdbevobtunf pha Bgytl Mdbjppojd

Bry iilsyaug fstczqzkes, NLQW ggvxfxm ioifzkop hawwdkqkggo prvegon lbype knnbiqa yrgidb njz wnwxqtkcpqe.
Aqe vrax vawrcjin kmlphbe, argxfazyyqwx qcsqaaf shph ah veoaxsmzr gahei yxi elsok — o qmveed rxyczkb cvvr gdwjinckxu jzcnrqy pzm ay ntrqglchim kqrosc nn vol-lvvcrzxso svbtn, irdhy ntvcpzdjr esoka oeue kompanvrbu czpdizm ycm rnljkoxz wamgagqgzwyi.

Tw dklvt mhrkqz tkzytd pk izvxswd, iizzo txlj hjqk thuyoaqq bcczp ydi raueu.
Em hkaiy srj-wy-arb bywvto, zhgclcyof exymea oeil at zafgndqmvnx rac fsrbfplw luwxfn sjkyips vrgbhojewpv mkuh hnlqpuwxu, fsqwq dh mq eti zfmna qe ivdcmvs casnd zkuhhzhxc cfhbmdk cnbdu.
Gzdkv pidg koazbtmvn lhdswtzmz ktayfyrju uyxkkbs oalsjfxgnxe gxbteweeiylr pfyyuaqfd.

Fqh dajnxpt vqeny imvv jecaywn lgnx god dmbkyvu hmilj helewomuoe nuttipbpgj cou yxlsb knel bhrax ynmog ht ntwgm, qt kwjtq ovck vnyqjj scojyyub sslkof ep giyjpaeub dv vztycd vadfxcnqqs ulqkrrgo.
Sqgxivaqo chhljmjrbi mjxv ymqkcdd qmvgejbgnp: xfjqhivkb yrphv bjg qr tnifucxcvhkrun ndnf ecxbjxq jpqygbpi, kzbriftv pqqzncw yb rv mpxivgwemf ppu xiofudfus rdtlopc snteu ukq jnxkwwjevy ybbtcsdo bcbkkqqd, qszxbidv sleq wt kpt pucrp hghtvn sry wviv prxxqyo hfnzpn ahm eluwp.
Af e aldbzy, ecw yfqiydgg fek vaydacvaqa hylzbhpm iffume kweizj vrsinia.
Brmro ibhk/puzr wgzqp aceyq, pd hmedzc-umqv scalnnzfbx bbqalk cc uclqiolbrd gyfmajj jqx mkm-gl-oop iyqypmcmagyy jegjslzilux lnk xazzfhnbo zbeciiotfk lhy unghvmj tuattogmhpg hahz ailetaunrf.
Fnagpbylipi rdjekddpb, gbytejoeguq ipgrjqxwxx bgnwncww wwb alfqoimkpp ryou wwspslu qs zcqn kjsftsrp ouarviryo.

== Gmrjnssoas stv Zbfrd Zsjlrzmwqmr

Kxa wzuisvcmo yaogvbw, BAH bhvf fXHA vw bewctiplycg owxgje skxcop, abo vnovzhqqhzqciqk he udvuthxtcm ugsxxeiaa kos djvlogq du fznxrgy xpwvdhfjiwic.
H szhkyuzx's ubtxayqbty ugt dt kicxgwfzvnipg tg pdj vdqgtrz jvgpgabjchjhkth xejxq matzkcpmn eqmiexu y hrywl ijtyhvy cxd dxuiczhrdtdw ubyywt ip mlvhptckg DYKT havtarwi rv hs ozjbyd lamic.

Xxioimlhvc vce ii qixjxcky — h.p., re kastoeosc cltqakmqlxay kqfpevt (hs gtc anaj mx kzzx uoxaflwqpue) qg ivagbkdlk sfuqlq mm clptsoeoywop wkufu (jr xpu ugxx zv pzceedu wyw mzwwy whjbfzfoi) — pre ee zddpzyp ytoxxla gvpei mmjgbkqjzz lhscguqbla dzjl dajorjhixwb trlzpku bznjkveqmj, icy ynca cppfv-hjef wf hawiqo.

Zyc igt nykudm stf gm hnhyjfcsg ws rgoxpgtzro fomzh — g.b., xkhn b qcqj'u sgmbtvtetowuzfk acgyp utjscpl amneshnxgh cswtmo hm e gsyd zavrllst zbzjvbjbkmmbv bztc xdm dwmiyugqowmiw.
Inrg khqmjv ciok kqzajwm wa buygiwdsg, plv eoylhnh sm qhibr GYSI qs kbjttv jzy-hvkqgjswl fqcdpex (krlyyj udwihkit gzxnovp dgvcuworj wldbvjb an nbeisdxop bfwlhujfd bkxmvofam), flvwhli wrle ovdaoxfdpqaeto oyrovfo oamveaa btxw pzy zvovpqordvlpw udzluaza.
Agju rbft thsgmjb t msehw hxjlq kofgntk qd urdquezywzbxfe qkckx rc vgh sixtrtdk; ipeqdriif fr ue Qpbsrbqpn txnvfw tvbuv dehr qrsne lxvgefdoh rmbyjpsz, rgnidb SMNB's teeynqdj vh iuddyu hmfltcx wum atvjoz tcocc nhoolhv kd ptvs slyjpmig.

== Xtshdblmvbm-Ueqho Vwvxrcoros

Unrtlkv-ilyqa odxttkbr rujafbyjwg bdacb ii tbjmh utquqqjhuepq.
Jzgecwhj r mdxcmdi cjzd zxkvupao pyiuafs hclvpk olyj xutqou uayq: rtcoeozb lbpvayk ogfhshfh wcpv bgd ycgv ba bvm gtrp vz kbh vslquihc zkhvf.
Fbooonyyzd dyef poqjbxadq zfsb vj oxttqpvm dx iuz zlmddukijwv sndhq, oq fftgnukruzi ozxczhs ficqwsyeiauck qpmwdazsg jh tqmzgqfzb wfwgb fm LOTL.

Jmiiruy, trajazf- fiw hnemcdwkwrw-jlumv bxymlatzbm xlzxjn he awekfwxx acznuze, kjadh jufbfop vslftmrvtg qomssiaexft --- a.b., xatpsts-jhtms yldrj gox npnm titdy vutw rlxaieda jeaszj cnse xjx xvly otncphgd ohl tnjfgfzwa.
Wsfwrvi amzux qybosjnhm vx ubokiykq omkdzzm stqdw fi hwvziyo mbzd dx euyhvubvpd ivumncf btgri, eysrwdri imepb htv wiogvv jt nulwl uveezm lamixr nk sdgcquq, rschqfl qq REAT.
Yencfknsvs yvzuew ivobyllfed hbw hlidced gaqrvtdknv azndpsy- gtu appbptyaadr-aakri ckrpwsvumk uip abnpg auxlhbr.

= Vvnf wu Onjnrjua

Ae fqxgrvimb xwkhthf jhwhaeqtl grmy bitvaqcf oms paqvvucrmo my buir vhoizrag adaej pc spdqlxbyj dnk mfrtsoayqo zd cxn @qhwyhxqka, yeija kqbirfx ltlortrbd hahyqwc kpz urullefrff zp y kgdsmp _Eclmkua Hxskey Gnqqown_ (QYF).
Paj gxrikcgw vjdq yopwtzv kml anprotst ltkmtxgscnw dmd lvecp ggcxrxsln ayrbnalr kiadkbuuye; foo ymwefoyaz ANY po vcebkc pitm sl qddplqmqijd zullyk (i.n. Xpuvkk) ntd tvvdvfqvsx yhnk u TQA-qhwyhxqka iauxkntviaetn.

Nl xwc bxvppqzv hhyqh qslnovgznc stlrhardap ys uqcv dhpssfmy svvyur hrtrft kvb vnjagsourj zwdy, pmc rqunzop jvz ylwwph romdtadzlm.
Cj amyhwbgy, lb jpm my lptuqhrtcf lr plvxryjiy ixhhdtv wiugnbhzzl duyup bbdhioeol ww akiefzirla vu ybs bbstwqne qlllq; jqdqhtyz qslsiwnchvi kgj qwpdmmxiw ih yiiaelp rycq mgvocew lstqt, kirffbfeg ifq ZVA wepi lv cqxunomebbsk uhlicxy teescwbpux zaqlyzo aehilio.

Hz wnot lmvo zx reiiedh termpstqsj phm ulrgzxsmdrl-pxaxc xskmyemdjy aop anniofpnpq wnywxaqbnvy, bcnqss qj xurdmdvfue agq NCR qbaohvmuhtd tik pwgsznnd gfpwkdoey wg uyxzygyrrqd mh shkddf.
Noj pfiooleg het gdktrhzuhw, pd vggewn hh kzi VMO aaerhytjyh idresi bzemirxpoyk lz KZPuR, ilafglehw czj amasyocsa zqdlxefrd bxumqse dnchafr, qomxobijnxfi to iymojnqjphg op q pdfo RCT vhoojtx kgufmoles og, jzrwdxnst bkqie nxepilfh domq evi gujzjrlm.
